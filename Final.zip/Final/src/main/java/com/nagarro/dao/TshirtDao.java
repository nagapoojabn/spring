package com.nagarro.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nagarro.dto.DtoInput;
import com.nagarro.model.Tshirt;
import com.nagarro.session.HibernateUtil;

public class TshirtDao {

	public static List<Tshirt> SearchTshirt(DtoInput input) {
		Transaction tx = null;
		Session session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();

		StringBuilder sb = new StringBuilder(
				"from Tshirt where colour = :colour and gender = :gender and size = :size and availability = :availability");

		if (input.getOutputpreference() == 1) {
			sb.append(" order by price ");
		} else if (input.getOutputpreference() == 2) {
			sb.append(" order by rating DESC");
		} else {
			sb.append(" order by price ASC , rating DESC");
		}
		@SuppressWarnings("rawtypes")
		Query query = session.createQuery(sb.toString());
		query.setParameter("colour", input.getColour());
		query.setParameter("gender", input.getGender());
		query.setParameter("size", input.getSize());
		query.setParameter("availability", true);
		List<Tshirt> sortedresult = query.list();
		tx.commit();
		session.close();

		return sortedresult;
	}
}
