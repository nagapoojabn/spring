package com.nagarro.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({ "com.nagarro.controller" })
public class DispatcherRequestControler {

}
