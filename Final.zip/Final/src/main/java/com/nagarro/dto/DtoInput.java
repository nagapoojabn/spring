package com.nagarro.dto;

public class DtoInput {
	private String colour;
	private String gender;
	private String size;
	private int outputpreference;

	/**
	 * @param colour
	 * @param gender
	 * @param size
	 */
	public DtoInput(String colour, String gender, String size, int outputpreference) {
		this.colour = colour;
		this.gender = gender;
		this.size = size;
		this.outputpreference = outputpreference;
	}

	public DtoInput() {

	}

	@Override
	public String toString() {
		return "DtoInput [colour=" + colour + ", gender=" + gender + ", size=" + size + ", outputpreference="
				+ outputpreference + "]";
	}

	/**
	 * @return the outputpreference
	 */
	public int getOutputpreference() {
		return outputpreference;
	}

	/**
	 * @param outputpreference the outputpreference to set
	 */
	public void setOutputpreference(int outputpreference) {
		this.outputpreference = outputpreference;
	}

	/**
	 * @return the colour
	 */
	public String getColour() {
		return colour;
	}

	/**
	 * @param colour the colour to set
	 */
	public void setColour(String colour) {
		this.colour = colour;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}
}
